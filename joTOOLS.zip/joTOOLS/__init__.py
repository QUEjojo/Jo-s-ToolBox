def classFactory(iface):
    from .plugin import joTOOLSPlugin
    return joTOOLSPlugin(iface)
