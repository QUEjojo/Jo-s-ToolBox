from qgis.PyQt.QtWidgets import (
    QDockWidget, QWidget, QVBoxLayout, QLabel, QPushButton, QComboBox, QDialog,
    QLineEdit, QFileDialog, QMessageBox, QHBoxLayout, QFormLayout, QListWidget,
    QTextEdit, QSizePolicy, QTabWidget
)
from qgis.PyQt.QtCore import Qt, QVariant
from qgis.PyQt.QtGui import QIntValidator
from qgis.core import (
    QgsProject, QgsSpatialIndex, QgsPointXY, QgsMapLayerType,
    QgsVectorLayer, QgsField, QgsFeature, QgsGeometry,
    QgsVectorFileWriter, QgsWkbTypes
)
import os
import re


class joTOOLSWindow(QDockWidget):
    def __init__(self, iface):
        super().__init__()
        self.iface = iface
        self.setWindowTitle("joTOOLS")

        self.main_widget = QWidget()
        self.setWidget(self.main_widget)

        main_layout = QVBoxLayout(self.main_widget)

        welcome_label = QLabel("Welcome to the Toolbox!")
        main_layout.addWidget(welcome_label)

        self.tab_widget = QTabWidget()
        main_layout.addWidget(self.tab_widget)

        # Address Tools tab
        address_tab = QWidget()
        address_layout = QVBoxLayout(address_tab)
        address_tab.setLayout(address_layout)
        self.tab_widget.addTab(address_tab, "Address Tools")

        btn_auto_address = QPushButton("Auto Address Creator")
        btn_auto_address.clicked.connect(self.launch_auto_address_dialog)
        address_layout.addWidget(btn_auto_address)

        btn_centralize = QPushButton("Centralize Address Points")
        btn_centralize.clicked.connect(self.launch_centralize_address_points_dialog)
        address_layout.addWidget(btn_centralize)

        btn_smart_split = QPushButton("Smart Split")
        btn_smart_split.clicked.connect(self.launch_smart_split_dialog)
        address_layout.addWidget(btn_smart_split)

        btn_unit_counter = QPushButton("Unit Counter")
        btn_unit_counter.clicked.connect(self.launch_unit_counter)
        address_layout.addWidget(btn_unit_counter)

        # Parcel Tools tab
        parcel_tab = QWidget()
        parcel_layout = QVBoxLayout(parcel_tab)
        parcel_tab.setLayout(parcel_layout)
        self.tab_widget.addTab(parcel_tab, "Parcel Tools")

        # Other Tools tab
        other_tab = QWidget()
        other_layout = QVBoxLayout(other_tab)
        other_tab.setLayout(other_layout)
        self.tab_widget.addTab(other_tab, "Other Tools")

        btn_delete_points = QPushButton("Delete Without External IDs")
        btn_delete_points.clicked.connect(self.launch_delete_without_external_ids_dialog)
        other_layout.addWidget(btn_delete_points)

        btn_duplicate_detector = QPushButton("Duplicate Detector")
        btn_duplicate_detector.clicked.connect(self.launch_duplicate_detector_dialog)
        other_layout.addWidget(btn_duplicate_detector)

        self.main_widget.setLayout(main_layout)

    # ---------- Common helpers ----------

    def _polygon_layers(self):
        return [
            lyr for lyr in QgsProject.instance().mapLayers().values()
            if isinstance(lyr, QgsVectorLayer)
            and lyr.geometryType() == QgsWkbTypes.GeometryType.PolygonGeometry
        ]

    def _point_layers(self):
        return [
            lyr for lyr in QgsProject.instance().mapLayers().values()
            if isinstance(lyr, QgsVectorLayer)
            and lyr.geometryType() == QgsWkbTypes.GeometryType.PointGeometry
        ]

    def _get_selected_layer(self, combo, geom_type, label=""):
        data = combo.currentData()
        if not data:
            return None
        lyr = QgsProject.instance().mapLayer(data)
        if not isinstance(lyr, QgsVectorLayer):
            return None
        if lyr.geometryType() != geom_type:
            return None
        return lyr

    # ---------- Auto Address Creator ----------

    def launch_auto_address_dialog(self):
        class AutoAddressDialog(QDialog):
            def __init__(self, parent=None):
                super().__init__(parent)
                self.setWindowTitle("Auto Address Creator")
                self.resize(520, 600)

                layout = QVBoxLayout(self)

                def add_layer_row(label):
                    row = QHBoxLayout()
                    row.addWidget(QLabel(label, self))
                    combo = QComboBox(self)
                    row.addWidget(combo)
                    layout.addLayout(row)
                    return combo

                self.parcel_combo = add_layer_row("Parcel Layer:")

                self.address_mode = QComboBox(self)
                self.address_mode.addItems(["Use existing layer", "Create new layer"])
                mode_row = QHBoxLayout()
                mode_row.addWidget(QLabel("Address Layer Mode:", self))
                mode_row.addWidget(self.address_mode)
                layout.addLayout(mode_row)

                self.new_layer_name = QLineEdit("New_Address_Layer", self)
                new_row = QHBoxLayout()
                new_row.addWidget(QLabel("New Layer Name:", self))
                new_row.addWidget(self.new_layer_name)
                layout.addLayout(new_row)
                self.new_layer_name.hide()

                self.address_combo = add_layer_row("Address Layer:")
                self.zip_combo = add_layer_row("Zip Code Layer:")
                self.da_combo = add_layer_row("DA Boundary Layer:")

                hut_row = QHBoxLayout()
                hut_row.addWidget(QLabel("Hut:", self))
                self.hut_combo = QComboBox(self)
                hut_row.addWidget(self.hut_combo)
                layout.addLayout(hut_row)

                census_mode_row = QHBoxLayout()
                census_mode_row.addWidget(QLabel("Census Tract Mode:", self))
                self.census_mode = QComboBox(self)
                self.census_mode.addItems(["Not Needed (opt out)", "Add layer input (opt in)"])
                census_mode_row.addWidget(self.census_mode)
                layout.addLayout(census_mode_row)

                self.census_layer_row = QHBoxLayout()
                self.census_layer_row.addWidget(QLabel("Census Tract Layer:", self))
                self.census_combo = QComboBox(self)
                self.census_layer_row.addWidget(self.census_combo)
                layout.addLayout(self.census_layer_row)
                for i in range(self.census_layer_row.count()):
                    w = self.census_layer_row.itemAt(i).widget()
                    if w:
                        w.hide()

                form_row = QHBoxLayout()
                left_form = QVBoxLayout()
                right_form = QVBoxLayout()
                form_row.addLayout(left_form, stretch=1)
                form_row.addLayout(right_form, stretch=1)
                layout.addLayout(form_row)

                def add_field(label, default=""):
                    row = QHBoxLayout()
                    row.addWidget(QLabel(label, self))
                    line = QLineEdit(default, self)
                    row.addWidget(line)
                    return row, line

                # LEFT COLUMN
                row, self.resource_input = add_field("Assigned Resource:", "CNS")
                left_form.addLayout(row)

                row, self.city_input = add_field("City:", "Memphis")
                left_form.addLayout(row)

                row, self.county_input = add_field("County:", "Shelby")
                left_form.addLayout(row)

                row, self.object_status = add_field("COS Object Status:", "Not deliverable")
                left_form.addLayout(row)

                row, self.contract_target_add = add_field("Contract Target Address?:", "UNK")
                left_form.addLayout(row)

                # RIGHT COLUMN
                row, self.client_input = add_field("Client:", "BSN")
                right_form.addLayout(row)

                row, self.state_input = add_field("State:", "TN")
                right_form.addLayout(row)

                row, self.country_input = add_field("Country:", "US")
                right_form.addLayout(row)

                row, self.object_id = add_field("COS Object ID:", "UNK")
                right_form.addLayout(row)

                row, self.deployment_input = add_field("OSP Deployment Status:", "Planned")
                right_form.addLayout(row)

                self.console = QTextEdit(self)
                self.console.setReadOnly(True)
                self.console.setFixedHeight(140)
                layout.addWidget(self.console)

                clear_btn = QPushButton("Clear Console", self)
                clear_btn.clicked.connect(self.clear_console)
                layout.addWidget(clear_btn)

                btn_row = QHBoxLayout()
                cancel_btn = QPushButton("Cancel", self)
                cancel_btn.clicked.connect(self.reject)
                run_btn = QPushButton("Run", self)
                run_btn.clicked.connect(self.run_process)
                btn_row.addWidget(cancel_btn)
                btn_row.addWidget(run_btn)
                layout.addLayout(btn_row)

                self.address_mode.currentIndexChanged.connect(self.update_mode_ui)
                self.da_combo.currentIndexChanged.connect(self.update_hut_options)
                self.census_mode.currentIndexChanged.connect(self.update_census_ui)

                self.populate_parcel_combo()
                self.populate_address_combo()
                self.populate_zip_combo()
                self.populate_da_combo()
                self.populate_census_combo()

            def log(self, msg):
                self.console.append(str(msg))
                self.console.verticalScrollBar().setValue(
                    self.console.verticalScrollBar().maximum()
                )

            def clear_console(self):
                self.console.clear()

            def _polygon_layers(self):
                return [
                    l for l in QgsProject.instance().mapLayers().values()
                    if isinstance(l, QgsVectorLayer)
                    and l.geometryType() == QgsWkbTypes.GeometryType.PolygonGeometry
                ]

            def _point_layers(self):
                return [
                    l for l in QgsProject.instance().mapLayers().values()
                    if isinstance(l, QgsVectorLayer)
                    and l.geometryType() == QgsWkbTypes.GeometryType.PointGeometry
                ]

            def populate_parcel_combo(self):
                self.parcel_combo.clear()
                for lyr in self._polygon_layers():
                    self.parcel_combo.addItem(lyr.name(), lyr.id())

            def populate_address_combo(self):
                self.address_combo.clear()
                for lyr in self._point_layers():
                    self.address_combo.addItem(lyr.name(), lyr.id())

            def populate_zip_combo(self):
                self.zip_combo.clear()
                for lyr in self._polygon_layers():
                    self.zip_combo.addItem(lyr.name(), lyr.id())

            def populate_da_combo(self):
                self.da_combo.clear()
                for lyr in self._polygon_layers():
                    self.da_combo.addItem(lyr.name(), lyr.id())

            def populate_census_combo(self):
                self.census_combo.clear()
                for lyr in self._polygon_layers():
                    self.census_combo.addItem(lyr.name(), lyr.id())

            def update_mode_ui(self):
                if self.address_mode.currentText() == "Create new layer":
                    self.address_combo.hide()
                    self.new_layer_name.show()
                else:
                    self.address_combo.show()
                    self.new_layer_name.hide()

            def update_hut_options(self):
                self.hut_combo.clear()
                name = self.da_combo.currentText()
                if not name or name.startswith("<"):
                    return
                layer = QgsProject.instance().mapLayersByName(name)[0]
                huts = sorted({
                    str(f["v_plan"]) for f in layer.getFeatures()
                    if "v_plan" in layer.fields().names() and f["v_plan"]
                })
                self.hut_combo.addItems(huts)

            def update_census_ui(self):
                show = self.census_mode.currentText().startswith("Add")
                for i in range(self.census_layer_row.count()):
                    w = self.census_layer_row.itemAt(i).widget()
                    if w:
                        w.show() if show else w.hide()

            def _required_fields(self):
                return {
                    'ID': QVariant.String,
                    'Street Number': QVariant.String,
                    'Street': QVariant.String,
                    'Unit Number': QVariant.String,
                    'Postal/Zip Code': QVariant.String,
                    'Lat': QVariant.Double,
                    'Lon': QVariant.Double,
                    'Township': QVariant.String,
                    'City': QVariant.String,
                    'Assigned Resource': QVariant.String,
                    'Client': QVariant.String,
                    'OLT Name': QVariant.String,
                    'Construction Area': QVariant.String,
                    'COS Object Group': QVariant.String,
                    'State/Province': QVariant.String,
                    'County': QVariant.String,
                    'Country': QVariant.String,
                    'COS Object Status': QVariant.String,
                    'OSP Deployment Status': QVariant.String,
                    'Right of Entry': QVariant.String,
                    'Contract Target Address?': QVariant.String,
                    'Object Type': QVariant.String,
                    'Build': QVariant.String,
                    'DA': QVariant.String,
                    'FDH': QVariant.String,
                    'Circuit ID': QVariant.String,
                    'CENSUS TRACT GEOID': QVariant.String,
                    'Note': QVariant.String,
                    'Public Note': QVariant.String,
                    'Homecount': QVariant.String,
                    'Excluded?': QVariant.String,
                    '130%_FPL': QVariant.String,
                    'COS Object ID': QVariant.String,
                    'External ID': QVariant.String,
                    'Vetro ID': QVariant.String,
                    'Terminal': QVariant.String,
                    'DELETE': QVariant.String,
                    'Location': QVariant.String,
                    'Market Specific Designation': QVariant.String,
                }

            def _landuse_map(self):
                return {
                    'commercial': 'COM',
                    'government': 'GOV',
                    'hoa': 'HOA',
                    'multiple buisness': 'MBU',
                    'mixed use': 'MXU',
                    'other': 'OTHER',
                    'deselected': 'OTHER',
                    'religious': 'REL',
                    'single-family': 'SFU',
                    'vacant': 'VAC',
                    'multi-family': 'MDU',
                    'parking': 'OTHER',
                }

            def create_new_address_layer(self):
                name = self.new_layer_name.text().strip()
                layer = QgsVectorLayer("Point?crs=EPSG:4326", name, "memory")
                pr = layer.dataProvider()
                for k, t in self._required_fields().items():
                    pr.addAttributes([QgsField(k, t)])
                layer.updateFields()
                QgsProject.instance().addMapLayer(layer)
                return layer

            def _get_selected_layer(self, combo, geom_type):
                data = combo.currentData()
                if not data:
                    return None
                lyr = QgsProject.instance().mapLayer(data)
                if not lyr or lyr.geometryType() != geom_type:
                    return None
                return lyr

            def run_process(self):
                parcel_layer = self._get_selected_layer(
                    self.parcel_combo, QgsWkbTypes.GeometryType.PolygonGeometry
                )
                zip_layer = self._get_selected_layer(
                    self.zip_combo, QgsWkbTypes.GeometryType.PolygonGeometry
                )
                da_layer = self._get_selected_layer(
                    self.da_combo, QgsWkbTypes.GeometryType.PolygonGeometry
                )
                census_layer = self._get_selected_layer(
                    self.census_combo, QgsWkbTypes.GeometryType.PolygonGeometry
                )

                if self.address_mode.currentText() == "Create new layer":
                    address_layer = self.create_new_address_layer()
                else:
                    address_layer = self._get_selected_layer(
                        self.address_combo, QgsWkbTypes.GeometryType.PointGeometry
                    )

                if not parcel_layer or not zip_layer or not da_layer or not census_layer or not address_layer:
                    QMessageBox.warning(self, "Missing Layers", "Please select valid layers.")
                    return

                parcel_addr_field = "PAR_ADDR1"

                da_index = QgsSpatialIndex(da_layer.getFeatures())
                zip_index = QgsSpatialIndex(zip_layer.getFeatures())
                address_index = QgsSpatialIndex(address_layer.getFeatures())
                census_index = QgsSpatialIndex(census_layer.getFeatures())

                da_by_id = {f.id(): f for f in da_layer.getFeatures()}
                zip_by_id = {f.id(): f for f in zip_layer.getFeatures()}
                census_by_id = {f.id(): f for f in census_layer.getFeatures()}

                self.log(f"Parcel count: {parcel_layer.featureCount()}")
                self.log(f"ZIP count: {zip_layer.featureCount()}")
                self.log(f"DA count: {da_layer.featureCount()}")
                self.log(f"Census Tract count: {census_layer.featureCount()}")

                required = self._required_fields()
                existing = [f.name() for f in address_layer.fields()]
                new_fields = [QgsField(k, t) for k, t in required.items() if k not in existing]
                if new_fields:
                    address_layer.dataProvider().addAttributes(new_fields)
                    address_layer.updateFields()

                idx = {k: address_layer.fields().indexOf(k) for k in required.keys()}
                landuse_map = self._landuse_map()

                address_layer.startEditing()
                added = 0

                for parcel in parcel_layer.getFeatures():
                    geom = parcel.geometry()
                    if not geom or geom.isEmpty():
                        continue

                    centroid = geom.centroid()
                    if not centroid or centroid.isEmpty():
                        continue

                    pt = centroid.asPoint()
                    cgeom = QgsGeometry.fromPointXY(QgsPointXY(pt))
                    exists = False
                    for aid in address_index.intersects(geom.boundingBox()):
                        feat = address_layer.getFeature(aid)
                        if feat and geom.contains(feat.geometry()):
                            exists = True
                            break
                    if exists:
                        continue

                    da_val = None
                    hut_val = None
                    for did in da_index.intersects(cgeom.boundingBox()):
                        f = da_by_id.get(did)
                        if f and f.geometry().contains(cgeom):
                            da_val = f["Project"]
                            hut_val = f["v_plan"]
                            break
                    if not da_val:
                        continue

                    zip_val = None
                    for zid in zip_index.intersects(cgeom.boundingBox()):
                        f = zip_by_id.get(zid)
                        if f and f.geometry().contains(cgeom):
                            zip_val = f["GEOID20"]
                            break
                    if not zip_val:
                        continue

                    geoid_val = None
                    msd_val = None
                    fpl_val = None
                    for cid in census_index.intersects(cgeom.boundingBox()):
                        f = census_by_id.get(cid)
                        if f and f.geometry().contains(cgeom):
                            geoid_val = f["GEOID"]
                            fpl_val = f["130%_FPL"]
                            msd_val = f["Market Specific Designation"]
                            break
                    if not geoid_val:
                        continue

                    raw = parcel[parcel_addr_field]
                    if raw is None:
                        continue

                    raw = str(raw).strip()
                    parts = raw.split(" ", 1)
                    num = parts[0]
                    street = parts[1] if len(parts) > 1 else ""
                    cleaned = re.sub(r"\s+", " ", raw)

                    feat = QgsFeature(address_layer.fields())
                    feat.setGeometry(cgeom)
                    attrs = [None] * len(address_layer.fields())

                    attrs[idx['ID']] = cleaned
                    attrs[idx['Street Number']] = num
                    attrs[idx['Street']] = street
                    attrs[idx['Postal/Zip Code']] = zip_val
                    attrs[idx['Lat']] = pt.y()
                    attrs[idx['Lon']] = pt.x()

                    landuse_value = parcel["LANDUSE"] if "LANDUSE" in parcel.fields().names() else None
                    normalized = landuse_value.strip().lower() if landuse_value else ""
                    object_type = next(
                        (abbrev for key, abbrev in landuse_map.items() if key.lower() in normalized),
                        "OTHER"
                    )
                    attrs[idx['Object Type']] = object_type
                    attrs[idx['Build']] = "No" if object_type in ["MDU", "MBU", "HOA", "OTHER"] else "Yes"
                    attrs[idx['Right of Entry']] = "Required" if object_type in ["MDU", "MBU", "HOA"] else "Not Required"

                    attrs[idx['City']] = self.city_input.text().strip()
                    attrs[idx['Assigned Resource']] = self.resource_input.text().strip()
                    attrs[idx['Client']] = self.client_input.text().strip()
                    attrs[idx['State/Province']] = self.state_input.text().strip()
                    attrs[idx['County']] = self.county_input.text().strip()
                    attrs[idx['Country']] = self.country_input.text().strip()
                    attrs[idx['COS Object Status']] = self.object_status.text().strip()
                    attrs[idx['OSP Deployment Status']] = self.deployment_input.text().strip()
                    attrs[idx['Contract Target Address?']] = self.contract_target_add.text().strip()
                    attrs[idx['COS Object ID']] = self.object_id.text().strip()
                    attrs[idx['DA']] = da_val
                    attrs[idx['FDH']] = da_val

                    hut_str = str(hut_val) if hut_val else ""
                    digits = "".join(filter(str.isdigit, hut_str))
                    if digits:
                        hut_num = digits.zfill(2)
                        attrs[idx['OLT Name']] = f"tn-mem.hut.MEM{hut_num}"
                        attrs[idx['Construction Area']] = f"Hut {hut_num}"
                    else:
                        attrs[idx['OLT Name']] = "tn-mem.hut.UNKNOWN"
                        attrs[idx['Construction Area']] = "Unknown"

                    attrs[idx['Circuit ID']] = f"{da_val} {cleaned.replace(',', '')}"
                    attrs[idx['CENSUS TRACT GEOID']] = geoid_val
                    attrs[idx['130%_FPL']] = fpl_val
                    attrs[idx['Market Specific Designation']] = msd_val

                    feat.setAttributes(attrs)
                    address_layer.addFeature(feat)
                    added += 1

                address_layer.commitChanges()
                self.log(f"Done. Added {added} addresses.")
                QMessageBox.information(self, "Done", f"Added {added} addresses.")
                self.accept()

        dialog = AutoAddressDialog(self)
        dialog.exec()

    # ---------- Delete Without External IDs ----------

    def launch_delete_without_external_ids_dialog(self):
        class DeleteWithoutExternalIDS(QDialog):
            def __init__(self, parent=None):
                super().__init__(parent)
                self.setWindowTitle("Delete w/out External IDS")

                layout = QVBoxLayout(self)

                layers = QgsProject.instance().mapLayers().values()
                vector_layers = [lyr for lyr in layers if lyr.type() == QgsMapLayerType.VectorLayer]
                layer_names = [lyr.name() for lyr in vector_layers]

                if not layer_names:
                    QMessageBox.warning(self, "No Layers", "No vector layers found.")
                    self.reject()
                    return

                self.combo = QComboBox()
                self.combo.addItems(layer_names)
                layout.addWidget(QLabel("Select Address Layer:"))
                layout.addWidget(self.combo)

                button_layout = QHBoxLayout()
                run_button = QPushButton("Run")
                cancel_button = QPushButton("Cancel")
                button_layout.addWidget(run_button)
                button_layout.addWidget(cancel_button)
                layout.addLayout(button_layout)

                cancel_button.clicked.connect(self.reject)
                run_button.clicked.connect(self.run_delete)

            def run_delete(self):
                selected_name = self.combo.currentText()
                try:
                    address_layer = QgsProject.instance().mapLayersByName(selected_name)[0]
                    address_layer.startEditing()

                    ids_to_delete = [
                        feature.id()
                        for feature in address_layer.getFeatures()
                        if not feature['External ID'] or str(feature['External ID']).strip() == ""
                    ]
                    if ids_to_delete:
                        address_layer.deleteFeatures(ids_to_delete)

                    address_layer.commitChanges()

                    result_dialog = QDialog(self)
                    result_dialog.setWindowTitle("Deletion Summary")
                    result_layout = QVBoxLayout(result_dialog)
                    result_layout.addWidget(
                        QLabel(f"{len(ids_to_delete)} address point(s) without External ID were deleted.")
                    )
                    close_btn = QPushButton("Close")
                    close_btn.clicked.connect(result_dialog.accept)
                    result_layout.addWidget(close_btn)
                    result_dialog.setLayout(result_layout)
                    result_dialog.exec()
                except Exception as e:
                    QMessageBox.critical(self, "Error", f"Deletion failed:\n{str(e)}")
                self.accept()

        dialog = DeleteWithoutExternalIDS(self)
        dialog.exec()

    # ---------- Centralize Address Points ----------

    def launch_centralize_address_points_dialog(self):
        class CentralizerDialog(QDialog):
            def __init__(self, parent=None):
                super().__init__(parent)
                self.setWindowTitle("Centralize Addresses")

                layout = QVBoxLayout(self)

                layers = QgsProject.instance().mapLayers().values()
                vector_layers = [lyr for lyr in layers if lyr.type() == QgsMapLayerType.VectorLayer]
                self.vector_layers = vector_layers
                layer_names = [lyr.name() for lyr in vector_layers]

                if not layer_names:
                    QMessageBox.warning(self, "No Vector Layers", "No vector layers found in the project.")
                    self.reject()
                    return

                self.parcel_combo = QComboBox()
                self.address_combo = QComboBox()
                self.parcel_combo.addItems(layer_names)
                self.address_combo.addItems(layer_names)

                for label_text, combo in [
                    ("Parcel Layer:", self.parcel_combo),
                    ("Address Layer:", self.address_combo)
                ]:
                    row = QHBoxLayout()
                    row.addWidget(QLabel(label_text))
                    row.addWidget(combo)
                    layout.addLayout(row)

                ok_button = QPushButton("Centralize")
                ok_button.clicked.connect(self.on_ok_clicked)
                layout.addWidget(ok_button)

            def on_ok_clicked(self):
                parcel_layer_name = self.parcel_combo.currentText()
                address_layer_name = self.address_combo.currentText()

                parcel_layer = next((lyr for lyr in self.vector_layers if lyr.name() == parcel_layer_name), None)
                address_layer = next((lyr for lyr in self.vector_layers if lyr.name() == address_layer_name), None)

                if not parcel_layer or not address_layer:
                    QMessageBox.warning(self, "Layer Error", "Selected layers not found.")
                    return

                parcel_index = QgsSpatialIndex(parcel_layer.getFeatures())
                address_layer.startEditing()

                for address_feat in address_layer.getFeatures():
                    address_geom = address_feat.geometry()
                    if address_geom.type() != QgsWkbTypes.GeometryType.PointGeometry:
                        continue

                    intersecting_ids = parcel_index.intersects(address_geom.boundingBox())
                    for parcel_id in intersecting_ids:
                        parcel_feat = parcel_layer.getFeature(parcel_id)
                        if parcel_feat.geometry().contains(address_geom):
                            centroid = parcel_feat.geometry().centroid().asPoint()
                            new_geom = QgsGeometry.fromPointXY(QgsPointXY(centroid))
                            address_layer.changeGeometry(address_feat.id(), new_geom)
                            break

                address_layer.commitChanges()
                QMessageBox.information(self, "Success", "Address points centralized.")
                self.accept()

        dialog = CentralizerDialog(self)
        dialog.exec()

    # ---------- Unit Counter ----------

    def launch_unit_counter(self):
        class UnitNumberDialog(QDialog):
            def __init__(self, parent=None):
                super().__init__(parent)
                self.setWindowTitle("Unit Counter")

                layout = QVBoxLayout(self)

                self.layer_combo = QComboBox()
                self.layers_dict = {}
                for layer in QgsProject.instance().mapLayers().values():
                    if isinstance(layer, QgsVectorLayer):
                        self.layer_combo.addItem(layer.name())
                        self.layers_dict[layer.name()] = layer

                form_layout = QFormLayout()
                self.field_input = QLineEdit("Unit Number")
                self.units_input = QLineEdit("10")
                self.floors_input = QLineEdit("4")
                self.address_input = QLineEdit()
                self.status_label = QLabel("")

                form_layout.addRow("Select Layer:", self.layer_combo)
                form_layout.addRow("Field name:", self.field_input)
                form_layout.addRow("Units per floor:", self.units_input)
                form_layout.addRow("Total floors:", self.floors_input)
                form_layout.addRow("Target ID:", self.address_input)
                layout.addLayout(form_layout)

                run_button = QPushButton("Run")
                run_button.clicked.connect(self.run_script)
                layout.addWidget(run_button)
                layout.addWidget(self.status_label)

            def run_script(self):
                layer_name = self.layer_combo.currentText()
                layer = self.layers_dict.get(layer_name)
                if layer is None:
                    self.status_label.setText(f"Layer '{layer_name}' not found.")
                    return

                field_name = self.field_input.text().strip()
                if field_name not in [f.name() for f in layer.fields()]:
                    self.status_label.setText(f"Field '{field_name}' not found in {layer_name}.")
                    return

                try:
                    units_per_floor = int(self.units_input.text())
                    total_floors = int(self.floors_input.text())
                except ValueError:
                    self.status_label.setText("Units per floor and total floors must be integers.")
                    return

                target_address = self.address_input.text().strip()
                if not target_address:
                    self.status_label.setText("Please enter a target address.")
                    return

                if not layer.isEditable():
                    if not layer.startEditing():
                        self.status_label.setText("Failed to start editing layer.")
                        return

                field_index = layer.fields().indexOf(field_name)
                count = 0

                if "ID" not in [f.name() for f in layer.fields()]:
                    self.status_label.setText("Layer does not have an 'ID' field.")
                    return

                for feature in layer.getFeatures():
                    if feature["ID"] != target_address:
                        continue
                    floor = (count // units_per_floor) + 1
                    unit_index = (count % units_per_floor) + 1
                    if floor > total_floors:
                        break
                    unit_number = f"{floor}{str(unit_index).zfill(2)}"
                    if not layer.changeAttributeValue(feature.id(), field_index, unit_number):
                        self.status_label.setText(f"Failed to update feature {feature.id()}.")
                        layer.rollBack()
                        return
                    count += 1

                if count == 0:
                    self.status_label.setText(f"No features found for address '{target_address}'.")
                    layer.rollBack()
                    return

                if layer.commitChanges():
                    self.status_label.setText(f"Updated {count} features successfully.")
                else:
                    layer.rollBack()
                    self.status_label.setText("Failed to commit changes. Rolled back edits.")

        dialog = UnitNumberDialog(self)
        dialog.exec()

    # ---------- Duplicate Detector ----------

    def launch_duplicate_detector_dialog(self):
        class DuplicateDetectorDialog(QDialog):
            def __init__(self, parent=None):
                super().__init__(parent)
                self.setWindowTitle("Duplicate Detector")

                layout = QVBoxLayout(self)

                self.layer_combo = QComboBox()
                self.field_combo = QComboBox()
                self.result_list = QListWidget()
                self.layers_dict = {}

                for layer in QgsProject.instance().mapLayers().values():
                    if layer.type() == QgsMapLayerType.VectorLayer:
                        self.layer_combo.addItem(layer.name())
                        self.layers_dict[layer.name()] = layer

                form_layout = QFormLayout()
                form_layout.addRow("Select Layer:", self.layer_combo)
                form_layout.addRow("Field to Check:", self.field_combo)
                layout.addLayout(form_layout)

                layout.addWidget(self.result_list)

                run_btn = QPushButton("Run")
                layout.addWidget(run_btn)

                self.layer_combo.currentIndexChanged.connect(self.update_field_combo)
                run_btn.clicked.connect(self.run_detection)

                self.update_field_combo()

            def update_field_combo(self):
                layer_name = self.layer_combo.currentText()
                layer = self.layers_dict.get(layer_name)
                self.field_combo.clear()
                if layer:
                    self.field_combo.addItems([f.name() for f in layer.fields()])

            def run_detection(self):
                layer_name = self.layer_combo.currentText()
                field_name = self.field_combo.currentText()
                layer = self.layers_dict.get(layer_name)

                if not layer or field_name not in [f.name() for f in layer.fields()]:
                    QMessageBox.warning(self, "Invalid Input", "Please select a valid layer and field.")
                    return

                value_counts = {}
                for feature in layer.getFeatures():
                    value = str(feature[field_name])
                    value_counts[value] = value_counts.get(value, 0) + 1
                duplicates = [val for val, count in value_counts.items() if count > 1]

                self.result_list.clear()
                self.result_list.addItem(f"Found {len(duplicates)} duplicate value(s):")
                for val in duplicates:
                    self.result_list.addItem(f"{val} ({value_counts[val]} occurrences)")

                duplicate_ids = [
                    feature.id()
                    for feature in layer.getFeatures()
                    if str(feature[field_name]) in duplicates
                ]
                layer.selectByIds(duplicate_ids)

        dialog = DuplicateDetectorDialog(self)
        dialog.exec()

    # ---------- Smart Split ----------

    def launch_smart_split_dialog(self):
        class AddressSplitterDialog(QDialog):
            def __init__(self, parent=None):
                super().__init__(parent)
                self.setWindowTitle("Smart Split")

                layout = QVBoxLayout(self)

                self.layer_combo = QComboBox()
                self.layers_dict = {}

                for layer in QgsProject.instance().mapLayers().values():
                    if layer.type() == QgsMapLayerType.VectorLayer:
                        self.layer_combo.addItem(layer.name())
                        self.layers_dict[layer.name()] = layer

                form_layout = QFormLayout()
                form_layout.addRow("Layer:", self.layer_combo)

                self.address_input = QLineEdit()
                form_layout.addRow("Target Address:", self.address_input)

                self.units_input = QLineEdit()
                self.units_input.setValidator(QIntValidator(1, 1000))
                form_layout.addRow("Number of Units:", self.units_input)

                self.field_input = QLineEdit()
                form_layout.addRow("Field to update:", self.field_input)

                self.style_combo = QComboBox()
                self.style_combo.addItems([
                    "Numeric (101, 102, 103, ... )",
                    "Letters (A, B, C, ... )",
                    "Simple (1, 2, 3, ... )"
                ])
                form_layout.addRow("Unit numbering style:", self.style_combo)

                self.status_label = QLabel("")

                layout.addLayout(form_layout)

                button_layout = QHBoxLayout()
                run_button = QPushButton("Run")
                cancel_button = QPushButton("Cancel")
                button_layout.addWidget(run_button)
                button_layout.addWidget(cancel_button)
                layout.addLayout(button_layout)

                cancel_button.clicked.connect(self.reject)
                run_button.clicked.connect(self.run_split)

                layout.addWidget(self.status_label)

            def run_split(self):
                layer_name = self.layer_combo.currentText()
                layer = self.layers_dict.get(layer_name)

                if layer is None:
                    self.status_label.setText(f"Layer '{layer_name}' not found.")
                    return

                field_name = self.field_input.text().strip()
                if field_name not in [f.name() for f in layer.fields()]:
                    self.status_label.setText(f"Field '{field_name}' not found in {layer_name}.")
                    return

                target_address = self.address_input.text().strip()
                if not target_address:
                    self.status_label.setText("Please enter a target address.")
                    return

                try:
                    units = int(self.units_input.text())
                except ValueError:
                    self.status_label.setText("Units must be a valid integer.")
                    return

                if not layer.isEditable():
                    if not layer.startEditing():
                        self.status_label.setText("Failed to start editing layer.")
                        return

                if "ID" not in [f.name() for f in layer.fields()]:
                    self.status_label.setText("Layer does not have an 'ID' field.")
                    return

                original_feature = None
                for feature in layer.getFeatures():
                    if str(feature["ID"]).strip() == target_address:
                        original_feature = feature
                        break

                if original_feature is None:
                    self.status_label.setText(f"No feature found for address '{target_address}'.")
                    layer.rollBack()
                    return

                geom = original_feature.geometry()
                if geom.isNull() or geom.type() != QgsWkbTypes.GeometryType.PointGeometry:
                    self.status_label.setText("Original feature does not have a valid point geometry.")
                    layer.rollBack()
                    return

                point = geom.asPoint()
                x, y = point.x(), point.y()

                new_features = []
                style = self.style_combo.currentText()

                for unit_index in range(1, units + 1):
                    if style == "Numeric (101, 102, 103, ... )":
                        unit_number = str(100 + unit_index)
                    elif style == "Letters (A, B, C, ... )":
                        unit_letter = chr(65 + unit_index - 1)
                        unit_number = unit_letter
                    elif style == "Simple (1, 2, 3, ... )":
                        unit_number = str(unit_index)
                    else:
                        unit_number = str(unit_index)

                    new_feature = QgsFeature(layer.fields())
                    excluded_fields = {"fid", "vetro_id", "External ID"}
                    for field in layer.fields():
                        if field.name() not in excluded_fields:
                            new_feature.setAttribute(field.name(), original_feature[field.name()])

                    new_feature.setAttribute(field_name, unit_number)

                    original_id = str(original_feature["ID"]).strip()
                    new_feature.setAttribute("ID", f"{original_id} Unit {unit_number}")
                    if "Circuit ID" in [f.name() for f in layer.fields()]:
                        original_circuit_id = str(original_feature["Circuit ID"]).strip()
                        new_feature.setAttribute("Circuit ID", f"{original_circuit_id} Unit {unit_number}")

                    new_geom = QgsGeometry.fromPointXY(QgsPointXY(x, y))
                    new_feature.setGeometry(new_geom)
                    new_features.append(new_feature)

                if layer.addFeatures(new_features):
                    if layer.commitChanges():
                        self.status_label.setText(f"Created {units} new unit features successfully.")
                    else:
                        layer.rollBack()
                        self.status_label.setText("Failed to commit changes. Rolled back edits.")
                else:
                    layer.rollBack()
                    self.status_label.setText("Failed to add new features.")

        dialog = AddressSplitterDialog(self)
        dialog.exec()

#--------------------------------------------------
    def launch_generic_dialog(self, title):
        dialog = QDialog(self)
        dialog.setWindowTitle(title)
        self.layout = QVBoxLayout()
        layout.addWidget(self.tabs)
        dialog.setLayout(layout)
        dialog.exec()

