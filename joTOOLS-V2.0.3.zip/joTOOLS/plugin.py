import os
from qgis.PyQt.QtCore import Qt
from qgis.PyQt.QtWidgets import QAction, QToolBar
from qgis.PyQt.QtGui import QIcon
from .joTOOLSWindow import joTOOLSWindow

class joTOOLSPlugin:
    def __init__(self, iface):
        self.iface = iface
        self.action = None
        self.toolbar = None
        self.dock_widget = None

        self.plugin_dir = os.path.dirname(__file__)

    def initGui(self):
        icon_path = os.path.join(self.plugin_dir, "joTOOLS icon.jpg")

        self.action = QAction(
            QIcon(icon_path),
            "joTOOLS",
            self.iface.mainWindow()
        )
        self.action.setObjectName("joTOOLS")
        self.action.setToolTip("Open joTOOLS toolbox")

        self.toolbar = QToolBar("joTOOLS")
        self.toolbar.setObjectName("joTOOLSToolbar")
        self.toolbar.addAction(self.action)
        self.iface.addToolBar(self.toolbar)

        self.iface.addPluginToMenu("&joTOOLS", self.action)

        self.action.triggered.connect(self.run)

    def unload(self):
        if self.toolbar:
            self.iface.mainWindow().removeToolBar(self.toolbar)
            self.toolbar = None

        if self.action:
            self.iface.removePluginMenu("&joTOOLS", self.action)
            self.action = None

        if self.dock_widget:
            self.iface.removeDockWidget(self.dock_widget)
            self.dock_widget = None

    def run(self):
        if not self.dock_widget:
            self.dock_widget = joTOOLSWindow(self.iface)

        self.iface.addDockWidget(
            Qt.DockWidgetArea.RightDockWidgetArea,
            self.dock_widget
        )
        self.dock_widget.show()

